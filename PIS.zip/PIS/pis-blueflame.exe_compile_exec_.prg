CLOSE ALL
CLEAR ALL
CLEAR
WAIT WINDOW 'COMPILING - please wait' NOWAIT
DO "D:\Dev\GSIA\pis\pis\BF_PIS\deco\pis-blueflame.exe_compile_data_.prg"
SET BELL TO ('C:\Windows\Media\tada.wav')
?? CHR(7)
WAIT WINDOW 'FINISHED'
QUIT
