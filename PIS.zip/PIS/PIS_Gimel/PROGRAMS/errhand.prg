MESSAGEBOX( ;
          "Insufficient Virtual Memory",  ;
          16, "Message")
QUIT
ENDPROC
**
