public puser, xpay, xpis, xequip, myconn, nconn, xconn, yconn     

SET TALK OFF
SET ECHO OFF
SET STATUS OFF
SET SAFETY OFF
SET CENTURY ON
SET SYSMENU TO
SET SYSMENU AUTOMATIC
SET DELETED ON
SET EXCLUSIVE OFF
LOCAL lcsys16, lcprogram
lcsys16 = SYS(16)
lcprogram = SUBSTR(lcsys16,  ;
            AT(":", lcsys16) -  ;
            1)
CD LEFT(lcprogram, RAT("\",  ;
   lcprogram))
IF RIGHT(lcprogram, 3) = "FXP"
     CD ..
ENDIF
SET PATH TO 'class, data, forms, forms2, icon, images, programs, reports, reports2,  menus, text, pix'
OPEN DATABASE Sec SHARED

IF  .NOT. USED('fileloc')
     USE SHARED fileloc
     REPLACE conn WITH conn_bf
ENDIF

xpay	= fileloc.schemapay 
xpis	= fileloc.schemapis 
xequip 	= fileloc.schemaequip

_SCREEN.icon = 'ICON\SCDREQL.ICO'
_SCREEN.windowstate = 2
_SCREEN.showtips = .T.
_SCREEN.picture = 'fleck.jpg'
_SCREEN.closable = .T.
UPDATE fileloc SET conn = conn_bf

lnconn = SQLCONNECT(ALLTRIM(fileloc.conn))
IF lnconn < 1
     MESSAGEBOX("Failed to connect to server",'Message')
     RETURN
ENDIF
xconn 	= SQLCONNECT(ALLTRIM(fileloc.conn))
myconn	= SQLCONNECT(ALLTRIM(fileloc.conn))

SQLEXEC(lnconn,  "SELECT * from  " + xpis + ".version",  "curVersion")
SQLEXEC(lnconn,  "show errors",  "curVersionError")

SQLDISCONNECT(lnconn)
IF curversion.version > 5
     MESSAGEBOX('New version has been released, please use the latest version',  'Message')
     QUIT
     RETURN
ENDIF

ON SHUTDOWN QUIT
lnconn 	= SQLCONNECT(ALLTRIM(fileloc.conn))
yconn 	= SQLCONNECT(ALLTRIM(fileloc.conn))

IF lnconn < 1
     Messagebox("Failed to connect to server", 'Message')
     RETURN
ENDIF
SQLEXEC(lnconn, "USE " + xpis)
SQLEXEC(lnconn,  "SELECT * from " + xpis + ".CoInfo",  "curCoInfo")

SQLDISCONNECT(lnconn)
SELECT fileloc
REPLACE coname WITH  ALLTRIM(curcoinfo.coname)
REPLACE coadd WITH  ALLTRIM(curcoinfo.coadd)

IF USED("curCoInfo")
     SELECT curcoinfo
     USE
ENDIF

DO update 

_SCREEN.caption = fileloc.coname
DO FORM login
READ EVENTS
SET SYSMENU TO DEFAULT