PUBLIC xconn
SELECT fileloc
xconn = SQLCONNECT(ALLTRIM(fileloc.conn))
WAIT WINDOW NOWAIT  ;
     'Processing please wait!......'
ENDPROC
**
