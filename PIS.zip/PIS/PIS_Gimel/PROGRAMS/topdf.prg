PROCEDURE ToPDF
PARAMETER creportname AS STRING,  cfilter AS STRING

TRY
     IF	cfilter == .F.
        cfilter = ""
     ENDIF
CATCH

ENDTRY

nmsg = MESSAGEBOX("Export to PDF?", 0292,  "Message")
IF nmsg == 7
     ccmd = "REPORT FORM " +  creportname + " " +  cfilter +  "to printer prompt nodialog preview"
     &cCmd
ELSE
     SET PROCEDURE TO utilityReportListener.prg ADDITIVE
     
     LOCAL loxfrx, lnretval
     loxfrx 		= xfrx("XFRX#LISTENER")
     lnretval 		= loxfrx.setparams("output.pdf",  ,  .T.,  ,  ,  ,  "PDF")
     
     IF	lnretval 	= 0
        ccmd = "REPORT FORM " +  creportname +  " " + cfilter +  " OBJECT loxfrx"
        &cCmd
        
        IF 	FILE("C:\Program Files (x86)\Foxit Software\Foxit Reader\FoxitReader.exe")
        	RUN ("C:\Program Files (x86)\Foxit Software\Foxit Reader\FoxitReader.exe"  "output.pdf")
	    ELSE 
	    	IF 	FILE("C:\Program Files (x86)\Foxit Software\Foxit Reader\Foxit Reader.exe")
        		RUN ("C:\Program Files (x86)\Foxit Software\Foxit Reader\Foxit Reader.exe"  "output.pdf")
	    	ELSE
	        	IF 	FILE('C:\Program Files\Foxit Software\Foxit Reader\Foxit Reader.exe')
	        		RUN ("C:\Program Files\Foxit Software\Foxit Reader\Foxit Reader.exe"  "output.pdf")
	        	ELSE 
	        		IF 	FILE('C:\Program Files\Foxit Software\Foxit Reader\FoxitReader.exe')
	        			RUN ("C:\Program Files\Foxit Software\Foxit Reader\FoxitReader.exe"  "output.pdf")
	        		ELSE 
	        			MESSAGEBOX('No foxit reader installed!','Message')
	        		ENDIF 
	        	ENDIF 
	        ENDIF 
	    ENDIF 
        
     ELSE
          MESSAGEBOX("An error has occurred.",  "Error")
     ENDIF
     
ENDIF