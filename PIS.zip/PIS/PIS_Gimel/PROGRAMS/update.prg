xconn = SQLCONNECT(ALLTRIM(fileloc.conn))


*--- Create parameter table with fields checking for designation table creation --------------
msql  = " CREATE TABLE if not exists " + xpis + ".`para` ( " + ; 
		"	  `Id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, " + ; 
		"	  `desigTblCreated` SMALLINT UNSIGNED NOT NULL DEFAULT 0, " + ; 
		"	  PRIMARY KEY(`Id`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 		

msql  = " select * from " + xpis + ".`para` limit 1 " 
SQLEXEC(xconn,msql,'xpara')
IF 	RECCOUNT("xpara") < 1 
	msql = "INSERT INTO " + xpis + ".para  (desigTblCreated) VALUES (0) ; "
	SQLEXEC(xconn,msql)
ENDIF  		

msql  = " select * from " + xpis + ".`para` limit 1 " 
SQLEXEC(xconn,msql,'xpara')

IF 	xpara.desigTblCreated = 0 
	msql = "update " + xpis + ".empmas set desig_ = position_ where position_ in ('SG','LG'); " 
	SQLEXEC(xconn,msql)
	
	msql = "update " + xpis + ".para set desigTblCreated = 1 ; " 
	SQLEXEC(xconn,msql)
	
ENDIF 


*----- Designation  --------------------------------------------------------------------
msql =  " CREATE TABLE " + xpis + ".`designation` ( " + ; 
		"  `Code` CHAR(5) NOT NULL, " + ; 
		"  `Name` VARCHAR(45), " + ; 
		"  PRIMARY KEY(`Code`)) ENGINE = InnoDB;" 
SQLEXEC(xconn,msql) 
msql = "select * from " + xpis + ".designation limit 1 " 
SQLEXEC(xconn,msql,'x12')
SQLEXEC(xconn,'show errors','x12_error')

IF 	RECCOUNT('x12') < 1 
	msql = "insert into " + xpis + ".designation (Code, 	Name) values " + ; 
			" ('EMP', 'Employee'), " + ; 
			" ('SG',  'Security Guard'), " + ; 
			" ('LG',  'Lady Guard'), " + ; 
			" ('HG',  'Head Guard'), " + ; 
			" ('OIC', 'Officer-In-Charge'), " + ; 
			" ('SIC', 'Shift-In-Charege'), " + ; 
			" ('DC',  'Detachment Commander'), " + ; 
			" ('ADC', 'Assistant Detachment Commander') " 
			
	SQLEXEC(xconn,msql) 
	SQLEXEC(xconn,'show errors','Errordesignation') 
ENDIF 

*----- Add Designation  Code to Empmas --------------------------------------------------------------------
msql =  " ALTER TABLE " + xpis + ".`empmas` " + ; 
		" ADD COLUMN `desig_` CHAR(5) DEFAULT 'EMP', ENGINE = InnoDB;" 
SQLEXEC(xconn,msql) 


*--- Create BI Table  ---------------------------------------------------------------------
msql = " CREATE TABLE if not exists " +  ;
       xpis + ".BI ( " +  ;
       " `empnumber` 				char(5) NOT NULL,   " +  ;
       " `NB_DateConducted` 		date 				DEFAULT NULL,   " +  ;
       " `NB_DateEncoded` 			date 				DEFAULT NULL,   " +  ;
       " `NB_Feedback` 				int(10) unsigned 	DEFAULT NULL,   " +  ;
       " `NB_PersonInterviewed` 	varchar(60) 		DEFAULT NULL,   " +  ;
       " `NB_Relation` 				varchar(45) 		DEFAULT NULL,   " +  ;
       " `NB_VerifiedBy` 			varchar(60) 		DEFAULT NULL,   " +  ;
       " `NB_DateVerified` 			date 				DEFAULT NULL,   " +  ;
       " `NB_Remarks` 				varchar(200) 		DEFAULT NULL,   " +  ;
       " `Brgy_DateConducted` 		date 				DEFAULT NULL,   " +  ;
       " `Brgy_DateEncoded` 		date 				DEFAULT NULL,   " +  ;
       " `Brgy_Record` 				int(10) unsigned 	DEFAULT NULL,   " +  ;
       " `Brgy_PersonInterviewed` 	varchar(60) 		DEFAULT NULL,   " +  ;
       " `Brgy_PersonPostion` 		varchar(45) 		DEFAULT NULL,   " +  ;
       " `Brgy_DateVerified` 		date 				DEFAULT NULL,   " +  ;
       " `Brgy_VerifiedBy` 			varchar(60)			DEFAULT NULL,   " +  ;
       " `Brgy_Remarks` 			varchar(200) 		DEFAULT NULL,   " +  ;
       " `Emp_DateConducted` 		date 				DEFAULT NULL,   " +  ;
       " `Emp_DateEncoded` 			date 				DEFAULT NULL,   " +  ;
       " `Emp_Accountability` 		int(10) unsigned 	DEFAULT NULL,   " +  ;
       " `Emp_PersonInterviewed` 	varchar(60) 		DEFAULT NULL,   " +  ;
       " `Emp_PersonPostion` 		varchar(45) 		DEFAULT NULL,   " +  ;
       " `Emp_VerifiedBy` 			varchar(60) 		DEFAULT NULL,   " +  ;
       " `Emp_DateVerified` 		date 				DEFAULT NULL,   " +  ;
       " `Emp_Remarks` 				varchar(200) 		DEFAULT NULL,   " +  ;
       " `Sch_DateConducted` 		date 				DEFAULT NULL,   " +  ;
       " `Sch_Status` 				char(10) 			DEFAULT NULL,   " +  ;
       " `Sch_Course` 				varchar(80) 		DEFAULT NULL,   " +  ;
       " `Sch_LevelCompletion` 		int(10) unsigned 	DEFAULT NULL,   " +  ;
       " `Sch_PersonInterviewed` 	varchar(60) 		DEFAULT NULL,   " +  ;
       " `Sch_PersonPostion` 		varchar(45) 		DEFAULT NULL,   " +  ;
       " `Sch_VerifiedBy` 			varchar(60) 		DEFAULT NULL,   " +  ;
       " `Sch_DateVerified` 		date 				DEFAULT NULL,   " +  ;
       " `Sch_Remarks` 				varchar(200) 		DEFAULT NULL,   " +  ;
       " PRIMARY KEY (`empnumber`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
SQLEXEC(xconn, msql)


*----- Employee Compliance Record --------------------------------------------------------------------
msql = " CREATE TABLE " + xpis + ".`ComplianceRec` ( " + ; 
		 " `empnumber` 			CHAR(5) NOT NULL, " + ; 
		 " `CategoryId` 		INTEGER UNSIGNED, " + ; 
		 " `EmploymentModeId` 	INTEGER UNSIGNED, " + ; 
		 " `Source` 			VARCHAR(45), " + ; 
		 " PRIMARY KEY(`empnumber`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 

*----- Employment Mode  --------------------------------------------------------------------
msql = " CREATE TABLE " + xpis + ".`EmploymentMode` ( " + ;  
		" `Id` 		INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, " + ; 
		" `Name` 	VARCHAR(60) NOT NULL, " + ; 
		" PRIMARY KEY(`Id`)) ENGINE = InnoDB " 
SQLEXEC(xconn,msql) 

msql = "select * from " + xpis + ".EmploymentMode limit 1 " 
SQLEXEC(xconn,msql,'x1')

IF 	RECCOUNT('x1') < 1 
	msql = "insert into " + xpis + ".EmploymentMode (Name) values " + ; 
			" ('Direct Application'), " + ; 
			" ('Referral by a Friend'), " + ; 
			" ('Recruitment Agencies'),  " + ; 
			" ('Job Fairs'),  " + ;
			" ('Online Job Boards'),  " + ; 
			" ('Company Websites'),  " + ;
			" ('Social Media'),  " + ; 
			" ('Internships'),  " + ;
			" ('Freelancing'),  " + ; 
			" ('Temp Agencies'),  " + ; 
			" ('Government Job Centers'),  " + ; 
			" ('Networking'),  " + ;
			" ('Cold Calling'),  " + ; 
			" ('Volunteering'),  " + ; 
			" ('Job Referral Programs'),  " + ; 
			" ('Alumni Networks'),  " + ; 
			" ('Professional Associations'),  " + ; 
			" ('Career Counseling Centers'),  " + ; 
			" ('Company Events'),  " + ; 
			" ('Trade Shows'),  " + ; 
			" ('Job Search Apps'),  " + ; 
			" ('Company Newsletters'),  " + ; 
			" ('Cold Emails'),  " + ; 
			" ('Industry-Specific Websites'),  " + ; 
			" ('Freelance Platforms'),  " + ; 
			" ('Job Alerts'),  " + ; 
			" ('Company Research'),  " + ; 
			" ('Consulting Firms'),  " + ; 
			" ('Remote Work Platforms'), " + ;
			" ('Job Shadowing'),  " + ;
			" ('Company Internship Programs'),  " + ;
			" ('Freelance Marketplaces'),  " + ;
			" ('Job Placement Agencies'),  " + ;
			" ('LinkedIn Networking'),  " + ;
			" ('Company Conferences'),  " + ;
			" ('Job Search Engines'),  " + ;
			" ('Company Open Houses'),  " + ;
			" ('Job Coaches'),  " + ;
			" ('Temporary-to-Permanent Roles'),  " + ;
			" ('Job Portals'),  " + ;
			" ('Company Intranets'),  " + ;
			" ('Professional Certifications'),  " + ;
			" ('Job Aggregators'),  " + ;
			" ('Job Application Tracking Systems'),  " + ;
			" ('Freelance Networking Events'),  " + ;
			" ('Company Alumni Networks'),  " + ;
			" ('Job Search Clubs'),  " + ;
			" ('Company Blogs'),  " + ;
			" ('Industry Forums'),  " + ;
			" ('Company Talent Pools'),  " + ;
			" ('Job Search Consultants'),  " + ;
			" ('Company Webinars'),  " + ;
			" ('Job Search Seminars'),  " + ;
			" ('Company Diversity Programs'),  " + ;
			" ('Job Search Podcasts'),  " + ;
			" ('Company Employee Referral Bonuses'),  " + ;
			" ('Job Search '),  " + ;
			" ('Company Initiatives') " 
 	SQLEXEC(xconn,msql) 
	SQLEXEC(xconn,'show errors','ErrorJob') 
ENDIF  
 

		 
*---- SEc Lic Revalidation field ------------------------------------------------------
msql = "ALTER TABLE "+xpis+".`seclic` ADD COLUMN `licDateIssued` DATE DEFAULT '0000-00-00' AFTER `dateModified` , ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 
msql = "ALTER TABLE "+xpis+".`secliclogs` ADD COLUMN `licDateIssued` DATE DEFAULT '0000-00-00' AFTER `dateModified` , ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 

*----- Resigned Remarks --------------------------------------------------------------------
msql = "ALTER TABLE "+xpis+".`statusremarks` ADD COLUMN `ResignedRem` CHAR(200) Default ' ' AFTER `Remarks` , ENGINE = InnoDB;" 
SQLEXEC(xconn,msql) 

*----- Employee Compliance Category --------------------------------------------------------------------
msql = " CREATE TABLE if not exists "+xpis+".`EmpComplianceCategory` ( " + ; 
		 " `Id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, " + ; 
		 " `Name` VARCHAR(60), " + ; 
		 " PRIMARY KEY(`Id`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 

SQLEXEC(xconn,"select * from  "+xpis+".`EmpComplianceCategory` limit 1 ", "x")
IF 	RECCOUNT('x') = 0 
	SQLEXEC(xconn,"insert into  "+xpis+".`EmpComplianceCategory` (Name) values " + ; 
						" ('Security Officer'), ('CCT Operator'), ('Security Guard'), ('Lady Guard')", "x")
ENDIF 


*----- Employee Compliance List --------------------------------------------------------------------
msql = " CREATE TABLE if not exists "+xpis+".`EmpComplianceList` ( " + ; 
		"	  `Id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, " + ; 
		"	  `EmpComplianceCategoryId` INTEGER UNSIGNED DEFAULT 0,  " + ; 
		"	  `Name` VARCHAR(45) DEFAULT ' ',  " + ; 
		"	  PRIMARY KEY(`Id`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 

SQLEXEC(xconn,"select * from  "+xpis+".`EmpComplianceList` limit 1 ", "x")
IF 	RECCOUNT('x') = 0 
	SQLEXEC(xconn,"insert into  "+xpis+".`EmpComplianceList` (Name) values " + ; 
						" ('Applicant Tracking Form') " + ; 
						" ,('Written Examination') " + ; 
						" ,('Interview Form') " +; 
						" ,('Employment Contract') " +; 
						" ,('PVC ID') " +; 
						" ,('Orientation Attendance')  " +; 
						" ,('Consent Form')   " +; 
						" ,('Non Disclosure Agreement')  " +; 
						" ,('Training Passport')  " +; 
						" ,('201 File')  " +; 
						" ,('ATM Application')  " +; 
						" ,('NBI Verification')   " +; 
						" ,('License Verification') ", "x")
ENDIF 


*----- Employee Compliance --------------------------------------------------------------------
msql = " CREATE TABLE if not exists "+xpis+".`EmpCompliance` ( " + ; 
		"	  `Empnumber` CHAR(5) NOT NULL, " + ; 
		"	  `EmpComplianceListId` INTEGER UNSIGNED NOT NULL, " + ; 
		"	  `DateCompleted` DATE, " + ; 
		"	  `DateValidated` DATE, " + ; 
		"	  `RefNo` CHAR(25), " + ; 
		"	  `Status` CHAR(10), " + ; 
		"	  `Remarks` VARCHAR(80), " + ; 
		"	  `CompDeadline` date DEFAULT NULL, " + ; 
		"	  PRIMARY KEY(`Empnumber`, `EmpComplianceListId`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 

msql = " ALTER TABLE " + xpis +  ;
       ".`empcompliance` ADD COLUMN `CompDeadline` DATE; "
SQLEXEC(xconn, msql)

RETURN 


***********************************************************************************************
*--- Transferred Status ------------------------------------------------------------------------
**--- 1) 
msql = 	" CREATE TABLE if not exists "+ xpis + ".empstat_in ( " + ; 
		"		code CHAR NOT NULL,   PRIMARY KEY(`code`)) ENGINE = InnoDB;"
SQLEXEC(xconn,msql)
msql = 	" select * from "+ xpis + ".empstat_in "
SQLEXEC(xconn,msql,"xstatusIn")

IF 	RECCOUNT('xstatusIn') = 0 
	msql = "insert into " + xpis + ".empstat_in (code) values ('F'),('_'),('O')" 
	SQLEXEC(xconn,msql)
ENDIF 

**--- 2) 
msql = 	" CREATE TABLE if not exists "+ xpis + ".empstat_out ( " + ; 
		"		code CHAR NOT NULL,   PRIMARY KEY(`code`)) ENGINE = InnoDB;"
SQLEXEC(xconn,msql)
msql = 	" select * from "+ xpis + ".empstat_out "
SQLEXEC(xconn,msql,"xstatusOut")

IF 	RECCOUNT('xstatusOut') = 0 
	msql = "insert into " + xpis + ".empstat_out (code) values ('0'),('F'),('_')" 
	SQLEXEC(xconn,msql)
ENDIF 

*--- Transferred Status ------------------------------------------------------------------------
***********************************************************************************************


*--- Allowed status in movehdr table ------------------------------------------------------------------------
msql = 	" CREATE TABLE if not exists "+ xpis + ".`movehdr_status` ( " + ; 
  		" `Code` CHAR(1) NOT NULL, PRIMARY KEY(`Code`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql)
*SQLEXEC(xconn,'show errors','movehdr_statusError20230814')

 *--- Audit Trail - Log --------------------------------------------------------------------------------------
msql = 	" CREATE TABLE if not exists "+ xpis + ".movehdr_status_trail ( " + ; 
				"  Id 			INTEGER 		UNSIGNED NOT NULL AUTO_INCREMENT, " + ; 
				"  usr 			VARCHAR(55)		, " + ; 
				"  code 		CHAR(1)			, " + ; 
				"  action 		CHAR(1)			, " + ; 
				"  activity 	DATETIME		, " + ; 
				"  PRIMARY KEY(`Id`)) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql)
SQLEXEC(xconn,'show errors','movehdr_status_trailError20230814') 

*--- Add userno to security license ------------------------------------------------------------------------
msql = 	" ALTER TABLE "+ xpis + ".seclic ADD COLUMN `user` CHAR(25) AFTER `valStatus`,  ADD COLUMN `dateModified` DATETIME AFTER `user` , ENGINE = InnoDB;" 
SQLEXEC(xconn,msql)
*SQLEXEC(xconn,'show errors','seclicError20220124')

msql = "CREATE TABLE if not exists "+ xpis + ".`seclicLogs` (  `empnumber` char(5) NOT NULL,  	`sbrno` char(25) ,  	`opno` char(25) ,  " + ; 
			 " `validated` date ,  				`vfee` double(18,2) 	DEFAULT '0.00',  " + ; 
			 " `revalidated` date ,  			`valStatus` char(15) 	DEFAULT '',  " + ; 
			 " `user` char(25) DEFAULT NULL,  	`dateModified` datetime DEFAULT NULL ) " + ; 
			 " ENGINE=InnoDB DEFAULT CHARSET=utf8; " 
SQLEXEC(xconn,msql)
*SQLEXEC(xconn,'show errors','seclicLogsError20230129')
														 
*-----------------------------------------------------------------------------------------------------------




msql = " CREATE TABLE  if NOT exists "+ xpis + ".`trainhdr` (  " + ; 
			" `idtrainhdr` 		int(10) unsigned NOT NULL AUTO_INCREMENT,  " + ; 
			" `transno` 		int(10) unsigned 	DEFAULT NULL, " + ; 
			" `idtraincategory` int(10) unsigned 	DEFAULT NULL, " + ; 
			" `idtrainProgram` 	int(10) unsigned 	DEFAULT NULL,  " + ; 
			" `location` 		varchar(80) 		DEFAULT NULL,    " + ; 
			" `trainor` 		varchar(60) 		DEFAULT NULL,    " + ; 
			" `batch` 			char(10) 			DEFAULT NULL,    " + ; 
			" `dateStart` 		date 				DEFAULT NULL,    " + ; 
			" `dateEnd` 		date 				DEFAULT NULL,    " + ; 
			" `timeStart` 		datetime 			DEFAULT NULL,    " + ; 
			" `timeEnd` 		datetime 			DEFAULT NULL,    " + ; 
			" `Description` 	varchar(80) 		DEFAULT NULL,    " + ; 
			" `host` 			varchar(60) 		DEFAULT NULL,    " + ; 
			" `isFinalized` 	int(10) unsigned 	DEFAULT '0',    " + ; 
			" `Type` 			char(10) 			DEFAULT NULL,    " + ; 
			" `Remarks` 		varchar(80) 		DEFAULT NULL,    " + ; 
			" PRIMARY KEY (`idtrainhdr`)) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1; " 
SQLEXEC(xconn,msql)
SQLEXEC(xconn,'show errors','TrainHdrCreateError')
			
msql = " CREATE TABLE if NOT exists "+xpis+".`TrainingConfig` ( " +; 
		 "  `id` 			INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,  " + ;
		 "  `DispCnt` 		INTEGER UNSIGNED NOT NULL, " + ;
		 "  `DefTimeStart` 	INTEGER UNSIGNED NOT NULL, " + ;
		 "  `DefMinStart` 	INTEGER UNSIGNED NOT NULL, " + ;
		 "  `DefTimeEnd` 	INTEGER UNSIGNED NOT NULL, " + ;
		 "  `DefMinEnd` 	INTEGER UNSIGNED NOT NULL, " + ;
		 "  `DefType` 		VARCHAR(10) Default 'Internal', " + ;
		 "  PRIMARY KEY(`id`) ) ENGINE = InnoDB; " 
SQLEXEC(xconn,msql)
SQLEXEC(xconn,'show errors','TrainingConfigError')


msql = " select * from "  + xpis + ".`TrainingConfig` limit 1" 
SQLEXEC(xconn,msql,'CxTrainingConfig') 
IF 	RECCOUNT('CxTrainingConfig') < 1 
	msql = "insert into " + xpis + ".TrainingConfig (DispCnt, DefTimeStart, DefTimeEnd, DefMinStart, DefMinEnd, DefType) values " + ; 
												   "(100, 	  8, 			16, 		0,			 0, 		'Internal')" 
	SQLEXEC(xconn,msql)
	SQLEXEC(xconn,'show errors','InsertTrainingConfigError')												   
ENDIF 


msql = 	" CREATE TABLE  " + xpis + ".`TrainDtl` ( " + ; 
		" `IdTrainHdr` INTEGER UNSIGNED NOT NULL, " + ; 
  		" `empnumber` CHAR(5) NOT NULL,  " + ; 
  		" `remarks` VARCHAR(80) Default '',  " + ; 
  		" PRIMARY KEY(`IdTrainHdr`, `empnumber`)) ENGINE = InnoDB;" 
SQLEXEC(xconn,msql)
SQLEXEC(xconn,'show errors','TrainDtlError')												   
	

*!*	msql = " CREATE TABLE  " + xpis + ".`Traindtl` (  " + ; 
*!*			" `idtrainDtl` 	int(10) unsigned 	NOT NULL AUTO_INCREMENT,  " + ; 
*!*			" `idTrainHdr` 	int(10) unsigned 	NOT NULL,  " + ; 
*!*			" `empnumber` 	char(5) 			NOT NULL,  " + ; 
*!*			" `remarks` 	varchar(80) 		Default ' ',  " + ; 
*!*			" PRIMARY KEY (`idtrainDtl`)) " + ; 
*!*			" ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1; " 
*--- Create table TRainDtl 
IF 	USED("x")
	SELECT x 
	USE 
ENDIF 
SQLEXEC(yconn,"desc TrainDtl","x")
IF !USED("x")
	SQLEXEC(xconn,msql)
ELSE 

	IF 	USED("x1")
		SELECT x1 
		USE 
	ENDIF 
	SELECT * FROM x INTO CURSOR xmar 
	SELECT * FROM x WHERE UPPER(ALLTRIM(field)) = UPPER("IdTrainHdr") INTO CURSOR x1 
	IF 	RECCOUNT("x1") = 0 
		SQLEXEC(xconn, " drop table " + xpis + ".TrainDtl ")
		SQLEXEC(xconn,msql)
	ENDIF 
ENDIF 
		
*---- Training End Here  ---------------------------------------------------


msql = " CREATE TABLE if NOT exists "+xpis+".trans_ctr ( " + ; 
		 "  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,  " + ; 
		 "  `type` CHAR(12) DEFAULT ' ', " + ; 
		 "  `yr` INTEGER UNSIGNED DEFAULT 0, " + ; 
		 "  `mo` INTEGER UNSIGNED DEFAULT 0, " + ; 
		 "  `ctr` BIGINT UNSIGNED DEFAULT 0, " + ; 
		 "  PRIMARY KEY(`id`)) ENGINE = InnoDB; " 
		 
SQLEXEC(xconn,msql)
SQLEXEC(xconn,'show errors','transctrError')






msql = " CREATE TABLE "+xpis+".`secLic` ( " + ; 
		 " `empnumber` CHAR(5) NOT NULL, " + ; 
		 " `sbrno` CHAR(25) DEFAULT ' ', " + ; 
		 " `opno` CHAR(25) DEFAULT ' ', " + ; 
		 " `validated` DATE DEFAULT '0000-00-00', " + ; 
		 " PRIMARY KEY(`empnumber`)	) ENGINE = InnoDB;"
SQLEXEC(xconn,msql)

DO menu_insert_item

msql =  " CREATE TABLE  "+xpis+".`secLic_signatory` " + ; 
		" (`sig1` 		VARCHAR(80) NOT NULL, " + ; 
		"   `desig1` 	VARCHAR(80), " + ; 
		"   `sig2` 		VARCHAR(80), " + ; 
		"   `desig2` 	VARCHAR(80), " + ; 
		"   `sig3` 		VARCHAR(80), " + ; 
		"   `desig3` 	VARCHAR(80), " + ; 
		"   PRIMARY KEY (`sig1`)) ENGINE = InnoDB;  "
SQLEXEC(xconn,msql)

SQLEXEC(xconn,"select * from  "+xpis+".`secLic_signatory` ", "x")
IF 	RECCOUNT('x') = 0 
	SQLEXEC(xconn,"insert into  "+xpis+".`secLic_signatory` (sig1) values ('-')", "x")
ENDIF 


*---- SEc Lic Revalidation field ------------------------------------------------------
msql = "ALTER TABLE "+xpis+".`seclic` ADD COLUMN `revalidated` DATE DEFAULT '0000-00-00' " 
SQLEXEC(xconn,msql) 

*---- SEc Val Status field ------------------------------------------------------
msql = "ALTER TABLE "+xpis+".`seclic` ADD COLUMN `valStatus` char(15) default ' ' " 
SQLEXEC(xconn,msql) 


*--- Insurance Access -----------------------------------------------------------
msql = "ALTER TABLE "+xpis+".`usr` ADD COLUMN `withInsuranceAccess` INTEGER UNSIGNED DEFAULT 0 AFTER `status`, ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 

msql = "ALTER TABLE "+xpis+".`empmas` ADD COLUMN `suffix` CHAR(3) DEFAULT ' ' AFTER `empmidnm` " + ; 
		" , ENGINE = InnoDB; "
SQLEXEC(xconn,msql) 


*--- 
msql = " CREATE TABLE " + xpis + ".`LevMonLetter` ( " + ; 
	   " `lvnumber` 	CHAR(10) NOT NULL, " + ; 
	   " `empnumber` CHAR(10) NOT NULL, " + ; 
	   " `letter1` 	DATE default '0000-00-00', " + ; 
	   " `letter2` 	DATE default '0000-00-00', " + ; 
	   " `letter3` 	DATE default '0000-00-00', " + ; 
	   " `letter4` 	DATE default '0000-00-00', " + ; 
	   " `letter1by` CHAR(15) default ' ', " + ; 
	   " `letter2by` CHAR(15) default ' ', " + ; 
	   " `letter3by` CHAR(15) default ' ', " + ; 
	   " `letter4by` CHAR(15) default ' ', " + ; 
	   " PRIMARY KEY (`lvnumber`)) " 
SQLEXEC(xconn,msql) 	   

*---- DPA Integration -------------------------------------------
msql = 	" ALTER TABLE " + xpis + ".`empmas` " + ; 
			" ADD COLUMN `dpadate` DATE DEFAULT '0000-00-00' , " + ; 
			" ADD COLUMN `dpclient` CHAR(5) DEFAULT ' ';" 			
SQLEXEC(xconn,msql) 

msql = 	" CREATE TABLE " + xpis + ".`dpaStatusIncluded` " + ; 
		" (`dpaStatusIncluded` CHAR(2) DEFAULT ' ', " + ; 
		"   PRIMARY KEY (`dpaStatusIncluded`)) ENGINE = InnoDB;" 
SQLEXEC(xconn,msql) 
			   
			
*---- Increase address fields -------------------------------------
msql = " ALTER TABLE "+xpis+".`empmas` " + ; 
		" MODIFY COLUMN `ADDR1` VARCHAR(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL, " + ; 
		" MODIFY COLUMN `ADDR2` VARCHAR(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL " + ; 
		" , ENGINE = InnoDB;" 
		
SQLEXEC(xconn,msql) 


msql = 	" ALTER TABLE " + xpis + ".`client` MODIFY COLUMN `ADDR1` VARCHAR(150), " + ; 
										  " MODIFY COLUMN `ADDR2` VARCHAR(150); " 
SQLEXEC(xconn,msql) 			   
msql = 	" CREATE TABLE " + xpis + ".`InsuranceStatus` (`code` CHAR(2) NOT NULL,  PRIMARY KEY (`code`)) ENGINE = InnoDB;" 
SQLEXEC(xconn,msql) 	


*----- Employee status monitoring ---------------------------------------------------
msql = 	" CREATE TABLE " + xpis + ".`empstatmovement` (`id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, " + ; 
		"   `empnumber` CHAR(5) NOT NULL, " + ; 
		"   `user` 		VARCHAR(45), " + ; 
		"   `datemove` 	DATETIME, " + ; 
		"   `stat_from`	CHAR(15), " + ; 
		"   `stat_to`	CHAR(15), " + ; 
		"   `module` 	VARCHAR(30), " + ; 
		" 	PRIMARY KEY (`id`)) " + ; 
		" 	ENGINE = InnoDB; " 
SQLEXEC(xconn,msql) 	

*---- Add user create in query ------------------------------
msql = 	" ALTER TABLE  "+xpis+".`tblqueries` " + ; 
		" ADD COLUMN `logname` VARCHAR(25) DEFAULT ' ', ENGINE = InnoDB;" 
		
SQLEXEC(xconn,msql) 


*--- Create user empstatus access ------------------------------------
msql = 	" CREATE TABLE   "+xpis+".empstat_user_access ( " + ; 
		 " `empno` CHAR(5) NOT NULL, " + ; 
		 " `empstat_` CHAR(1) NOT NULL, " + ; 
		 " PRIMARY KEY(`empno`, `empstat_`)) ENGINE = InnoDB; "
SQLEXEC(xconn,msql) 


msql = 	" CREATE TABLE if NOT exists "+xpis+".regions ( " + ; 
		  " code 	CHAR(10) 	NOT NULL, " + ; 
		  " name 	VARCHAR(60) NOT NULL, " + ;
		  " odr 	int			NOT NULL, " + ; 
		  " PRIMARY KEY (code) ) ENGINE=InnoDB DEFAULT CHARSET=latin1;" 
SQLEXEC(xconn,msql) 
SQLEXEC(xconn,'show errors','xerrorCreate')

IF 	USED('x')
	SELECT x 
	USE 
ENDIF 

msql = "select * from " +xpis+".regions limit 1 "
SQLEXEC(xconn,msql,'x')
SQLEXEC(xconn,'show errors','xerror')

IF 	RECCOUNT('x') = 0 
	msql = "insert into " +xpis+".regions values " + ; 
				"('CAR', 	'Cordillera Administrative Region', 1),  " + ; 
				"('NCR', 	'National Capital Region', 2),  " + ; 
				"('BARMM', 	'Bangsamoro Autonomous Region in Muslim Mindanao', 3),  " + ; 
				"('I', 		'Ilocos Region', 4),  " + ; 
				"('II', 	'Cagayan Valley', 5),  " + ; 
				"('III', 	'Central Luzon', 6),  " + ; 
				"('IV-A', 	'CALABARZON', 7),  " + ; 
				"('IV-B', 	'MIMAROPA', 8),  " + ; 
				"('V', 		'Bicol Region', 9),  " + ; 
				"('VI', 	'Western Visayas', 10),  " + ; 
				"('VII', 	'Central Visayas', 11),  " + ; 
				"('VIII', 	'Eastern Visayas', 12),  " + ; 
				"('IX', 	'Zamboanga Peninsula', 13),  " + ; 
				"('X', 		'Northern Mindanao', 14),  " + ; 
				"('XI', 	'Davao Region', 15),  " + ; 
				"('XII', 	'SOCCSKARGEN', 16),  " + ; 
				"('XIII', 	'Caraga', 17)  "  
	SQLEXEC(xconn,msql)
ENDIF 

 


SQLDISCONNECT(xconn)
		