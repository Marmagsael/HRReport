? 'COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\MENUS\main.mpx"'
COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\MENUS\main.mpx"
? 'COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\cohdr.fxp"'
COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\cohdr.fxp"
? 'COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\conn.fxp"'
COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\conn.fxp"
? 'COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\errhand.fxp"'
COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\errhand.fxp"
? 'COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\main.fxp"'
COMPILE "D:\Dev\GSIA\pis\pis\BF_PIS\deco\PROGS\main.fxp"
? 'COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\buttons.vcx"'
COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\buttons.vcx"
? 'COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\common_forms.vcx"'
COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\common_forms.vcx"
? 'COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\eis.vcx"'
COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\eis.vcx"
? 'COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\geninfo.vcx"'
COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\geninfo.vcx"
? 'COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\pis.vcx"'
COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class\pis.vcx"
? 'COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class2\report.vcx"'
COMPILE CLASSLIB "D:\Dev\GSIA\pis\pis\BF_PIS\deco\class2\report.vcx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\archievingclient.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\archievingclient.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\assignment_his.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\assignment_his.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\assignmentorder.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\assignmentorder.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cand4active.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cand4active.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cand4awol.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cand4awol.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cand4floating.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cand4floating.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\changepassword.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\changepassword.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\civstat_entry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\civstat_entry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\clearances_rep.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\clearances_rep.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\clg_detail.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\clg_detail.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\clientareaentry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\clientareaentry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cliententry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\cliententry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\datehired.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\datehired.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\ddosum.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\ddosum.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\det_deviation.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\det_deviation.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\deviation.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\deviation.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\devtype_entry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\devtype_entry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\emp_insurance.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\emp_insurance.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\emp_masterlist.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\emp_masterlist.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empentry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empentry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empentry_search.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empentry_search.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empstat.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empstat.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empstat_entry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\empstat_entry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_list.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_list.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_main.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_main.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_proc.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_proc.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_type.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\equip_type.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\fed.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\fed.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\floatingemp.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\floatingemp.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\fmrquery.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\fmrquery.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\fmrquerynew.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\fmrquerynew.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\for_regular.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\for_regular.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\frmmr.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\frmmr.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\grprecall.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\grprecall.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\insurance_rep.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\insurance_rep.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\leave.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\leave.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\leavetype.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\leavetype.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\license_verification.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\license_verification.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\login.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\login.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\manpower_movement.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\manpower_movement.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\mla_code.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\mla_code.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\newly_hired.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\newly_hired.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\notice.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\notice.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\on_leave.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\on_leave.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\penaltytype_entry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\penaltytype_entry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\phic_er2.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\phic_er2.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\pnpsagsd.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\pnpsagsd.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\positionentry.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\positionentry.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\pro_code.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\pro_code.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\recall_order.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\recall_order.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\resigned.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\resigned.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\rtu.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\rtu.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\sss_r1a.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\sss_r1a.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\usermanager.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\usermanager.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\userrights.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms\userrights.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\archieving.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\archieving.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\emp_status.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\emp_status.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\equip_proclisting.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\equip_proclisting.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\equip_quickdeploy.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\equip_quickdeploy.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\flashscreen.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\flashscreen.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\frmcontren.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\frmcontren.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\frmcontrexpiration.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\frmcontrexpiration.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\listoffloating.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\listoffloating.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_age.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_age.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_devsumm.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_devsumm.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_explic.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_explic.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_recallsumm.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_recallsumm.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_rtusumm.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\rep_rtusumm.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\repage.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\repage.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\sdo.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\sdo.scx"
? 'COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\uniform.scx"'
COMPILE FORM "D:\Dev\GSIA\pis\pis\BF_PIS\deco\forms2\uniform.scx"
? '*'
